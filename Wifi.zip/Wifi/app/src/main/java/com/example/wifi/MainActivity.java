package com.example.wifi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
private Switch wifi_switch;
private Button AddNetworks ;
private WifiManager wifiManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       wifi_switch=findViewById(R.id.On_Off);
       AddNetworks=findViewById(R.id.Add_Network);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        boolean isWifiEnabled = wifiManager.isWifiEnabled();
        wifi_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                wifiManager.setWifiEnabled(true);
                wifi_switch.setText("ON");

                }
                else{
                    wifiManager.setWifiEnabled(false);
                    wifi_switch.setText("OFF");
                }

            }
        });
if(wifiManager.isWifiEnabled()){
    wifi_switch.setChecked(true);
    wifi_switch.setText("ON");
}
else {
    wifi_switch.setChecked(false);
    wifi_switch.setText("OFF");
}
AddNetworks.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        WifiConfiguration wifiConfig = new WifiConfiguration();
        wifiConfig.SSID="\"SSID_HERE\"";
        wifiConfig.preSharedKey="\"PASSWORD_HERE\"";
    int networkId= wifiManager.addNetwork(wifiConfig);
    if(networkId!=-1){
        wifiManager.enableNetwork(networkId,true);
    }
    else {
        Toast.makeText(getApplicationContext(),"Unable to add Network",Toast.LENGTH_SHORT).show();
    }
    }
});
    }


}




